---
name: 🐛 Bug Report
about: Report an issue found in the Deno CLI.
title: ''
labels: ''
assignees: ''
---

Version: Deno x.x.x
