Deno adheres to
[Rust's Code of Conduct](https://www.rust-lang.org/policies/code-of-conduct). In
the Github, Discord, and any other forums, every community member must follow
the rules and values expressed there. Please email conduct@deno.land to report
any instance of misconduct.
