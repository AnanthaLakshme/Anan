# Deno CLI Crate

[![crates](https://img.shields.io/crates/v/deno.svg)](https://crates.io/crates/deno)

This provides the actual deno executable and the user-facing APIs.

The deno crate uses the deno_core to provide the executable.
