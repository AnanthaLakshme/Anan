Enforces using types that are explicit or can be simply inferred.

Read more: https://jsr.io/docs/about-slow-types
