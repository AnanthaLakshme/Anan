// Copyright 2018-2024 the Deno authors. All rights reserved. MIT license.

// deno-lint-ignore-file no-console

const count = 100000;
for (let i = 0; i < count; i++) console.log("Hello World");
