benchmark filtering:

```
cargo bench --bench deno_bench -- bundle
```

benchmark plots:

new: https://denoland.grafana.net/d/vErC9VCnz/benchmarks?orgId=1 old:
deno.land/benchmarks
