# deno_fs

This crate provides ops for interacting with the file system.
