# deno_broadcast_channel

This crate implements the BroadcastChannel functions of Deno.

Spec: https://html.spec.whatwg.org/multipage/web-messaging.html
