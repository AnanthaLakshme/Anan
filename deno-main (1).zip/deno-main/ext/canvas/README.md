# deno_canvas

Extension that implements various OffscreenCanvas related APIs.
